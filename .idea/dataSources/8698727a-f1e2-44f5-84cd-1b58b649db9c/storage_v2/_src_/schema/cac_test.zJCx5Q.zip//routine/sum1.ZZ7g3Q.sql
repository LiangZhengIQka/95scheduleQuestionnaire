create
    definer = apptest@`%` procedure sum1(IN a int)
begin
     declare sum int default 0;
     declare i int default 1;
 while i<=a DO 
     set sum=sum+i;
     set i=i+1;
 end while; 
 select sum;  
 end;

