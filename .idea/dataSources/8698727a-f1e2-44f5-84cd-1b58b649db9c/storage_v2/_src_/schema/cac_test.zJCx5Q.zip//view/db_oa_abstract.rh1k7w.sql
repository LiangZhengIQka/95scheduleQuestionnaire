create definer = apptest@`%` view db_oa_abstract as
select `cac_test`.`db_oa_tb`.`inner_id`                            AS `inner_id`,
       date_format(`cac_test`.`db_oa_tb`.`created_tm`, '%Y-%m-%d') AS `created_tm`,
       count(`cac_test`.`db_oa_tb`.`id`)                           AS `num`
from `cac_test`.`db_oa_tb`
group by date_format(`cac_test`.`db_oa_tb`.`created_tm`, '%Y-%m-%d'), `cac_test`.`db_oa_tb`.`inner_id`
order by date_format(`cac_test`.`db_oa_tb`.`created_tm`, '%Y-%m-%d') desc;

