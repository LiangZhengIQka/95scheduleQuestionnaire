create definer = apptest@`%` view view_db_erppdmmail_history as
select `cac_test`.`db_erp_pdm_mail_tb`.`inner_id`                            AS `inner_id`,
       date_format(`cac_test`.`db_erp_pdm_mail_tb`.`created_tm`, '%Y-%m-%d') AS `created_tm`,
       sum(`cac_test`.`db_erp_pdm_mail_tb`.`PDM_num`)                        AS `PDM_num`,
       sum(`cac_test`.`db_erp_pdm_mail_tb`.`ERP_num`)                        AS `ERP_num`,
       sum(`cac_test`.`db_erp_pdm_mail_tb`.`mail_num`)                       AS `mail_num`
from `cac_test`.`db_erp_pdm_mail_tb`
group by date_format(`cac_test`.`db_erp_pdm_mail_tb`.`created_tm`, '%Y-%m-%d'),
         `cac_test`.`db_erp_pdm_mail_tb`.`inner_id`
order by date_format(`cac_test`.`db_erp_pdm_mail_tb`.`created_tm`, '%Y-%m-%d') desc;

