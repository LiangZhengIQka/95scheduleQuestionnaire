create definer = apptest@`%` view view_db_meeting_history_abstract as
select `u`.`inner_id`                            AS `inner_id`,
       date_format(`t`.`created_tm`, '%Y-%m-%d') AS `datetime`,
       count(distinct `u`.`meetingId`)           AS `num`
from (`cac_test`.`db_user_meeting_tb` `u`
         left join `cac_test`.`db_created_tm_meeting_tb` `t` on ((`t`.`meetingId` = `u`.`meetingId`)))
group by date_format(`t`.`created_tm`, '%Y-%m-%d'), `u`.`inner_id`
order by `t`.`created_tm` desc;

