create definer = apptest@`%` view view_temp as
select `e`.`inner_id`       AS `inner_id1`,
       `m`.`inner_id`       AS `inner_id2`,
       `o`.`inner_id`       AS `inner_id3`,
       `e`.`created_tm`     AS `dateTime1`,
       `m`.`datetime`       AS `dateTime2`,
       `o`.`created_tm`     AS `dateTime3`,
       `o`.`num`            AS `oa_num`,
       ifnull(`m`.`num`, 0) AS `meeting_num`,
       `e`.`PDM_num`        AS `PDM_num`,
       `e`.`ERP_num`        AS `ERP_num`,
       `e`.`mail_num`       AS `mail_num`
from ((`cac_test`.`view_db_erppdmmail_history` `e` left join `cac_test`.`view_db_meeting_history_abstract` `m` on ((
        (`m`.`inner_id` = `e`.`inner_id`) and (`m`.`datetime` = `e`.`created_tm`))))
         left join `cac_test`.`db_oa_abstract` `o`
                   on (((`o`.`inner_id` = `e`.`inner_id`) and (`o`.`created_tm` = `e`.`created_tm`))))
union
select `e`.`inner_id`       AS `inner_id1`,
       `m`.`inner_id`       AS `inner_id2`,
       `o`.`inner_id`       AS `inner_id3`,
       `e`.`created_tm`     AS `dateTime1`,
       `m`.`datetime`       AS `dateTime2`,
       `o`.`created_tm`     AS `dateTime3`,
       `o`.`num`            AS `oa_num`,
       ifnull(`m`.`num`, 0) AS `meeting_num`,
       `e`.`PDM_num`        AS `PDM_num`,
       `e`.`ERP_num`        AS `ERP_num`,
       `e`.`mail_num`       AS `mail_num`
from ((`cac_test`.`view_db_meeting_history_abstract` `m` left join `cac_test`.`view_db_erppdmmail_history` `e` on ((
        (`m`.`inner_id` = `e`.`inner_id`) and (`m`.`datetime` = `e`.`created_tm`))))
         left join `cac_test`.`db_oa_abstract` `o`
                   on (((`o`.`inner_id` = `e`.`inner_id`) and (`o`.`created_tm` = `e`.`created_tm`))))
union
select `e`.`inner_id`       AS `inner_id1`,
       `m`.`inner_id`       AS `inner_id2`,
       `o`.`inner_id`       AS `inner_id3`,
       `e`.`created_tm`     AS `dateTime1`,
       `m`.`datetime`       AS `dateTime2`,
       `o`.`created_tm`     AS `dateTime3`,
       `o`.`num`            AS `oa_num`,
       ifnull(`m`.`num`, 0) AS `meeting_num`,
       `e`.`PDM_num`        AS `PDM_num`,
       `e`.`ERP_num`        AS `ERP_num`,
       `e`.`mail_num`       AS `mail_num`
from (`cac_test`.`db_oa_abstract` `o`
         left join (`cac_test`.`view_db_meeting_history_abstract` `m` left join `cac_test`.`view_db_erppdmmail_history` `e` on ((
        (`m`.`inner_id` = `e`.`inner_id`) and (`m`.`datetime` = `e`.`created_tm`))))
                   on (((`o`.`inner_id` = `e`.`inner_id`) and (`o`.`created_tm` = `e`.`created_tm`))));

