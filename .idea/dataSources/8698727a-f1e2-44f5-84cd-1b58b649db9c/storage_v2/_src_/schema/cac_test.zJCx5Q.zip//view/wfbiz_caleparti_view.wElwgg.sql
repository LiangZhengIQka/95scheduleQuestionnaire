create definer = apptest@`%` view wfbiz_caleparti_view as
select `a`.`PARTICALEUUID` AS `PARTICALEUUID`,
       `a`.`PARTITYPE`     AS `PARTITYPE`,
       `a`.`PARTIID`       AS `PARTIID`,
       `a`.`PARTINAME`     AS `PARTINAME`,
       `a`.`CALENDARUUID`  AS `CALENDARUUID`,
       `a`.`CALETYPE`      AS `CALETYPE`,
       `a`.`UPTTIME`       AS `UPTTIME`,
       `b`.`TENANT_ID`     AS `TENANT_ID`,
       `b`.`CALENDARNAME`  AS `CALENDARNAME`
from (`cac_test`.`wfbiz_caleparti_relation` `a`
         join `cac_test`.`wfbiz_calendar_info` `b`)
where (`a`.`CALENDARUUID` = `b`.`CALENDARUUID`);

