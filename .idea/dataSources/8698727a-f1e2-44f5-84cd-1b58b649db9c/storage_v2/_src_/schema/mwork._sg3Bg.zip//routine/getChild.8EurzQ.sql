create
    definer = apptest@`%` function getChild(rootId varchar(36)) returns varchar(1000)
BEGIN
    DECLARE ptemp VARCHAR(1000);
    DECLARE ctemp VARCHAR(1000);
    SET ptemp = -1;
    SET ctemp = rootId;
    WHILE ctemp IS NOT NULL DO
      SET ptemp = concat(ptemp, ',', ctemp);
      SELECT group_concat(orgid)
      INTO ctemp
      FROM org_organization
      WHERE FIND_IN_SET(parentorgid, ctemp) > 0;
    END WHILE;
    RETURN ptemp;
  END;

