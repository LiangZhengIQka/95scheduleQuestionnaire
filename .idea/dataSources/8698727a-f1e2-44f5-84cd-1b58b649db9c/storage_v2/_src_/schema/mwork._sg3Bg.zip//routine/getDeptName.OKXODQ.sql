create
    definer = apptest@`%` procedure getDeptName(IN orgCode varchar(50))
BEGIN
    DECLARE orglevel INT DEFAULT 0;
    DECLARE orgparent INT DEFAULT 0;
    DECLARE orgchild VARCHAR(100) DEFAULT '';
    WHILE orglevel!='2'&&orglevel!='1' DO
			set orgchild =(SELECT oo.orgname from org_organization oo where oo.ORGID=orgCode);
      set orgparent=(SELECT oo.parentorgid from org_organization oo where oo.ORGID=orgCode);
			set orgCode=orgparent;
      set orglevel=(SELECT oo.orglevel from org_organization oo where oo.ORGID=orgparent);
		END WHILE;
		
		select orgchild;
END;

