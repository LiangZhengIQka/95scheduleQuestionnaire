create
    definer = apptest@`%` procedure sp_add(IN a int, IN b int, OUT c int)
begin

set c=a+ b;

end;

