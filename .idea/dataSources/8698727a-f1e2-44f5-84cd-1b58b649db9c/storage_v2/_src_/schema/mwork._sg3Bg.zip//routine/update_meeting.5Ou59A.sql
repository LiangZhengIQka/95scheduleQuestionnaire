create
    definer = apptest@`%` procedure update_meeting()
begin 
	
	declare _initiator varchar(45);	# initiator
	declare _mt_place varchar(45);	# mt_place
    declare _mt_type varchar(45);	# mt_type
    declare _start_tm TIMESTAMP;	# start_tm
    declare _end_tm TIMESTAMP;	# end_tm
    declare _created_tm TIMESTAMP;	# created_tm
    declare _open_mtname varchar(45);
    declare meeting_id INT;
    declare done int default false;
    declare done_tmp int default false;
    declare fetch_times int default 0;
	declare cur CURSOR FOR
		select distinct initiator, mt_place, mt_type, start_tm, end_time, created_tm, open_mtname 
        from db_oa_affairs_tb
        where system_name = "会议";
    declare continue handler for not found set done = TRUE;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN 
		ROLLBACK;
	END;

	START TRANSACTION;
	open cur; 
    REPEAT
		FETCH cur into _initiator, _mt_place, _mt_type, _start_tm, _end_tm, _created_tm, _open_mtname;
		if done = FALSE then
			set done_tmp = done;
			# select initiator, mt_place, start_tm, end_tm, created_tm;
			set meeting_id = 0;
			select meetingId into meeting_id from db_meeting_tb 
			where initiator = _initiator and mt_place = _mt_place and start_tm = _start_tm and end_tm = _end_tm;
		
			# 不存在，插入
			if meeting_id = 0 then
				insert into db_meeting_tb values (null, _initiator, _mt_place, _mt_type, _start_tm, _end_tm, _open_mtname);
				select last_insert_id() into meeting_id;
				# 插入会议-员工表
				insert into db_user_meeting_tb select null, inner_id, meeting_id from db_oa_affairs_tb 
				where initiator = _initiator and mt_place = _mt_place and start_tm = _start_tm and end_time = _end_tm; 
			end if;
			# 都需要插入到会议-更新时间表
			insert into db_created_tm_meeting_tb values (null, _created_tm, meeting_id);
			set done = done_tmp;
			set fetch_times = fetch_times + 1;
        end if;
	UNTIL done END REPEAT;		
	close cur;
    COMMIT;
    select fetch_times;
end;

