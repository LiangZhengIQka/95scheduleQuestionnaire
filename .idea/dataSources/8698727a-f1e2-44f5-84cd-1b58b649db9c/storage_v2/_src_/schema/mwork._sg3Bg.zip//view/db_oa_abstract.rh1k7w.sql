create view db_oa_abstract as
select `mwork`.`db_oa_tb`.`inner_id`                            AS `inner_id`,
       date_format(`mwork`.`db_oa_tb`.`created_tm`, '%Y-%m-%d') AS `created_tm`,
       count(`mwork`.`db_oa_tb`.`id`)                           AS `num`
from `mwork`.`db_oa_tb`
group by date_format(`mwork`.`db_oa_tb`.`created_tm`, '%Y-%m-%d'), `mwork`.`db_oa_tb`.`inner_id`
order by date_format(`mwork`.`db_oa_tb`.`created_tm`, '%Y-%m-%d') desc;

