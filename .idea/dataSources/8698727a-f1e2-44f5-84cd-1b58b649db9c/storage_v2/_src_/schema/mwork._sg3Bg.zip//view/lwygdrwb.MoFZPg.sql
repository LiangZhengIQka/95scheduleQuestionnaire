create view lwygdrwb as
select `s`.`dept_name`        AS `部门名称`,
       `t`.`user_name`        AS `姓名`,
       `t`.`user_code`        AS `工号`,
       `t`.`telephone_number` AS `电话号码`,
       `t`.`user_institution` AS `劳务派遣单位`
from `mwork`.`epidemic_basic_info` `t`
         join `mwork`.`epidemic_department` `s`
where ((`t`.`user_dept` = `s`.`dept_code`) and (not (exists(select 1
                                                            from `mwork`.`epidemic_report_info` `g`
                                                            where ((`t`.`identification_number` = `g`.`identification_number`) and
                                                                   (date_format(`g`.`create_date`, '%Y-%m-%d') =
                                                                    date_format(now(), '%Y-%m-%d')))))) and
       (`t`.`user_type` = '劳务用工'));

-- comment on column lwygdrwb.部门名称 not supported: 部门名称

-- comment on column lwygdrwb.姓名 not supported: 姓名

-- comment on column lwygdrwb.工号 not supported: 工号

-- comment on column lwygdrwb.电话号码 not supported: 手机号码

-- comment on column lwygdrwb.劳务派遣单位 not supported: 所属劳务派遣单位

