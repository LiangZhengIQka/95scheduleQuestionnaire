create view view_db_erppdmmail_history as
select `mwork`.`db_erp_pdm_mail_tb`.`inner_id`                            AS `inner_id`,
       date_format(`mwork`.`db_erp_pdm_mail_tb`.`created_tm`, '%Y-%m-%d') AS `created_tm`,
       sum(`mwork`.`db_erp_pdm_mail_tb`.`PDM_num`)                        AS `PDM_num`,
       sum(`mwork`.`db_erp_pdm_mail_tb`.`ERP_num`)                        AS `ERP_num`,
       sum(`mwork`.`db_erp_pdm_mail_tb`.`mail_num`)                       AS `mail_num`
from `mwork`.`db_erp_pdm_mail_tb`
group by date_format(`mwork`.`db_erp_pdm_mail_tb`.`created_tm`, '%Y-%m-%d'), `mwork`.`db_erp_pdm_mail_tb`.`inner_id`
order by date_format(`mwork`.`db_erp_pdm_mail_tb`.`created_tm`, '%Y-%m-%d') desc;

