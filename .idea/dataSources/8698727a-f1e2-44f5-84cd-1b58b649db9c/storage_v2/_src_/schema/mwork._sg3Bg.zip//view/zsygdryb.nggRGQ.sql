create view zsygdryb as
select `s`.`dept_name`                  AS `部门`,
       `t`.`user_name`                  AS `员工姓名`,
       `t`.`user_code`                  AS `工号`,
       `t`.`telephone_number`           AS `电话号码`,
       `g`.`if_leave_chengdu`           AS `1月8日起是否离开成都`,
       `g`.`destination`                AS `如果离开成都，行程目的地`,
       `g`.`if_back_to_chengdu`         AS `是否已返回成都`,
       `g`.`if_contact_suspected_cases` AS `你及家人是否接触确诊病例、接触疑似病例`,
       `g`.`if_contact_hb`              AS `你及家人是否接触湖北人`,
       `g`.`contact_date`               AS `接触疑似/确诊病患日期`,
       `g`.`health_condition`           AS `身体状况`,
       `g`.`if_go_to_doctor`            AS `未离开成都，如果接触过湖北人或疑似病例是否到医院筛查`,
       `g`.`examination_result`         AS `未离开成都，如果接触过湖北人或疑似病例到医院筛查的结果`,
       `g`.`back_date`                  AS `返回成都日期`,
       `g`.`examination_date`           AS `就诊日期`,
       `g`.`current_location`           AS `当前位置`,
       `g`.`record_date`                AS `填报时间`,
       `g`.`create_date`                AS `填报日期，每天只能填报一条`,
       `g`.`current_address`            AS `当前所在详细位置（定位信息）`
from `mwork`.`epidemic_basic_info` `t`
         join `mwork`.`epidemic_department` `s`
         join `mwork`.`epidemic_report_info` `g`
where ((`t`.`user_dept` = `s`.`dept_code`) and (`t`.`identification_number` = `g`.`identification_number`) and
       (date_format(`g`.`create_date`, '%Y-%m-%d') = date_format(now(), '%Y-%m-%d')) and (`t`.`user_type` = '正式员工'));

-- comment on column zsygdryb.部门 not supported: 部门名称

-- comment on column zsygdryb.员工姓名 not supported: 姓名

-- comment on column zsygdryb.工号 not supported: 工号

-- comment on column zsygdryb.电话号码 not supported: 手机号码

-- comment on column zsygdryb.`1月8日起是否离开成都` not supported: 1月8日起是否离开成都

-- comment on column zsygdryb.如果离开成都，行程目的地 not supported: 如果离开成都，行程目的地

-- comment on column zsygdryb.是否已返回成都 not supported: 是否已返回成都

-- comment on column zsygdryb.你及家人是否接触确诊病例、接触疑似病例 not supported: 你及家人是否接触确诊病例、接触疑似病例

-- comment on column zsygdryb.你及家人是否接触湖北人 not supported: 你及家人是否接触湖北人

-- comment on column zsygdryb.`接触疑似/确诊病患日期` not supported: 接触疑似/确诊病患日期

-- comment on column zsygdryb.身体状况 not supported: 身体状况

-- comment on column zsygdryb.未离开成都，如果接触过湖北人或疑似病例是否到医院筛查 not supported: 未离开成都，如果接触过湖北人或疑似病例是否到医院筛查

-- comment on column zsygdryb.未离开成都，如果接触过湖北人或疑似病例到医院筛查的结果 not supported: 未离开成都，如果接触过湖北人或疑似病例到医院筛查的结果

-- comment on column zsygdryb.返回成都日期 not supported: 返回成都日期

-- comment on column zsygdryb.就诊日期 not supported: 就诊日期

-- comment on column zsygdryb.当前位置 not supported: 当前位置

-- comment on column zsygdryb.填报时间 not supported: 填报时间

-- comment on column zsygdryb.填报日期，每天只能填报一条 not supported: 填报日期，每天只能填报一条

-- comment on column zsygdryb.当前所在详细位置（定位信息） not supported: 当前所在详细位置（定位信息）

